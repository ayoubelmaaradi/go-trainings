import Flow from './components/Flow';

const CampaignProfile = ({ steps })  => {
  return (
    <div style={{ height: '60%', width: '60%', backgroundColor: '#fffff' }}>
      <Flow mode="profile" steps={steps} />
    </div>
  );
};

export default CampaignProfile;